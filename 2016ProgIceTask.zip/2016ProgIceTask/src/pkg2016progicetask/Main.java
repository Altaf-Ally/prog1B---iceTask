/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg2016progicetask;
import java.util.Scanner;
/**
 *
 * @author altaafally
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

class Animal {
    int IDtag;
    String species;

    Animal(int IDtag, String species) {
        this.IDtag = IDtag;
        this.species = species;
    }

    void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter ID tag: ");
        IDtag = scanner.nextInt();
        System.out.print("Enter species: ");
        species = scanner.next();
    }

    void output() {
        System.out.println("ID tag: " + IDtag);
        System.out.println("Species: " + species);
    }
}

class Bird extends Animal {
    int colour;

    Bird(int IDtag, String species, int colour) {
        super(IDtag, species);
        this.colour = colour;
    }

    @Override
    void input() {
        super.input();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter feather colour (1=grey, 2=white, 3=black): ");
        colour = scanner.nextInt();
    }

    @Override
    void output() {
        super.output();
        System.out.println("Feather colour: " + colour);
    }
}

class Reptile extends Animal {
    double bloodTemp;

    Reptile(int IDtag, String species, double bloodTemp) {
        super(IDtag, species);
        this.bloodTemp = bloodTemp;
    }

    @Override
    void input() {
        super.input();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter blood temperature: ");
        bloodTemp = scanner.nextDouble();
    }

    @Override
    void output() {
        super.output();
        System.out.println("Blood temperature: " + bloodTemp);
    }
}
        Bird brd = new Bird(0, "", 0);
        Reptile rept = new Reptile(0, "", 0.0);

        brd.input();
        rept.input();

        System.out.println("\nBird information:");
        brd.output();

        System.out.println("\nReptile information:");
        rept.output();
    }
}

